<h2> Extension of PHASE-1 Algorithm </h2>

 <h4>Phase-2.Pdf has Instructions,Assumptions and Notations. <h4/>

 <h4>Phase-2.cpp has the C++ code that manipulates the instructions in Input.txt file and Prints the Output in Output.txt file. <h4/>

 <h4>output.txt file has all the outputs  <h4/>
