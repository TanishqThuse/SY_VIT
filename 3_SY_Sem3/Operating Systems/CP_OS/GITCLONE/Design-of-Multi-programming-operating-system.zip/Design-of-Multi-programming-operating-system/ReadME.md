<h1> Simulation of a Small operating system! <h1/>

<h3> the Code Manipulates the instruction given in Input file and writes the task done in Output file. <h3/>

<h4> CODE BY - <a href="https://github.com/kartikk10"> KARTIK KAPGATE </a>, <a href="https://github.com/adityaholkar">ADITYA HOLKAR </a> and <a href="https://github.com/fullpro">PRAFULL LAD</a> <b> (VIT,PUNE 17-21') </b> <h4/>
